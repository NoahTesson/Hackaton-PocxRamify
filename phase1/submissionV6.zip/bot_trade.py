# bot_trade.py – version améliorée et stabilisée

history = []

def make_decision(epoch: int, price: float):
    history.append(price)

    # Minimum pour statistiques robustes
    if len(history) < 40:
        return {"Asset A": 0.5, "Cash": 0.5}

    import math

    # === 1) Volatilité sur 20 périodes ===
    returns = [
        (history[i] - history[i-1]) / history[i-1]
        for i in range(len(history)-20, len(history))
    ]
    volatility = math.sqrt(sum(r*r for r in returns) / len(returns))

    # Empêcher explosion
    volatility = max(volatility, 1e-6)

    # === 2) Momentum via EMA (10 périodes) ===
    alpha = 2 / (10 + 1)
    ema = history[-11]
    for p in history[-10:]:
        ema = ema + alpha * (p - ema)
    momentum = (history[-1] - ema) / ema

    # === 3) Mean reversion ===
    ma30 = sum(history[-30:]) / 30
    deviation = (price - ma30) / ma30
    deviation /= volatility  # normalisation

    # === 4) Poids dynamiques selon volatilité ===
    # Plus la volatilité est élevée, plus momentum > mean reversion
    vol_factor = min(volatility * 50, 1.0)
    w_mom = 0.5 + 0.3 * vol_factor
    w_mr = 0.5 - 0.3 * vol_factor

    signal = w_mom * momentum - w_mr * deviation

    # === 5) Allocation par fonction sigmoïde ===
    # évite les sauts brusques
    from math import tanh
    allocation_asset = 0.5 + 0.4 * tanh(signal * 5)

    # bornes de sécurité
    allocation_asset = max(0.1, min(0.9, allocation_asset))

    return {
        "Asset A": allocation_asset,
        "Cash": 1 - allocation_asset
    }
