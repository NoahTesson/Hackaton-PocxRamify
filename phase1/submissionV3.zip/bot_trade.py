
history = []


def make_decision(epoch: int, price: float):
    history.append(price)

    if len(history) < 5:
        return {"Asset A": 0.5, "Cash": 0.5}

    short_window = 5
    long_window = 20

    short_slice = history[-short_window:]
    long_slice = history[-long_window:]

    short_ma = sum(short_slice) / len(short_slice)
    long_ma = sum(long_slice) / len(long_slice)

    if long_ma == 0:
        return {"Asset A": 0.5, "Cash": 0.5}

    signal = (short_ma - long_ma) / long_ma

    raw_alloc = 0.5 + 3 * signal

    allocation_asset = max(0.2, min(0.8, raw_alloc))

    return {
        "Asset A": allocation_asset,
        "Cash": 1 - allocation_asset
    }
