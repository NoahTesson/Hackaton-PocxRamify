# bot_trade.py – STRATÉGIE OPTIMISÉE POUR DATASET COURT ET MEAN-REVERTING

history = []

def make_decision(epoch: int, price: float):
    history.append(price)

    import math

    # Minimum warmup
    if len(history) < 20:
        return {"Asset A": 0.5, "Cash": 0.5}

    # ===========================
    # 1) Mean-Moving Average (20)
    # ===========================
    window = min(20, len(history))
    window_prices = history[-window:]
    mean = sum(window_prices) / window

    # ===========================
    # 2) Standard deviation
    # ===========================
    var = sum((p - mean) ** 2 for p in window_prices) / window
    std = math.sqrt(var) if var > 0 else 1e-6

    # ===========================
    # 3) Z-SCORE (mean reversion)
    # ===========================
    z = (price - mean) / std

    # ===========================
    # 4) Light momentum (confirmation only)
    # ===========================
    if len(history) >= 5:
        momentum = (price - history[-5]) / history[-5]
    else:
        momentum = 0.0

    # ===========================
    # 5) Combined signal
    # ===========================
    # Mean reversion dominant
    signal = -0.8 * z + 0.2 * momentum

    # ===========================
    # 6) Smooth allocation
    # ===========================
    from math import tanh
    allocation = 0.5 + 0.35 * tanh(signal * 1.8)

    # ===========================
    # 7) Bounds
    # ===========================
    allocation = max(0.15, min(0.85, allocation))

    return {
        "Asset A": float(allocation),
        "Cash": float(1 - allocation)
    }
