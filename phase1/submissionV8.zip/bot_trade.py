# bot_trade.py – version améliorée et stabilisée

history = []

def make_decision(epoch: int, price: float):
    history.append(price)

    # Minimum pour statistiques robustes
    if len(history) < 40:
        return {"Asset A": 0.5, "Cash": 0.5}

    import math

    # === 1) Volatilité sur 20 périodes ===
    returns = [
        (history[i] - history[i-1]) / history[i-1]
        for i in range(len(history)-20, len(history))
    ]
    volatility = math.sqrt(sum(r*r for r in returns) / len(returns))

    # Empêcher explosion
    volatility = max(volatility, 1e-6)

    # === 2) Momentum via EMA (10 périodes) ===
    alpha = 2 / (10 + 1)
    # Vérification nécessaire pour s'assurer que history[-11] existe
    start_index = max(0, len(history) - 11) 
    ema = history[start_index]
    
    # Correction de l'index de départ pour la boucle EMA
    for p in history[start_index + 1:]:
        ema = ema + alpha * (p - ema)
        
    momentum = (history[-1] - ema) / ema

    # === 3) Mean reversion ===
    ma30 = sum(history[-30:]) / 30
    deviation = (price - ma30) / ma30
    deviation /= volatility  # normalisation

    # === 4) Poids dynamiques selon volatilité ===
    # Plus la volatilité est élevée, plus momentum > mean reversion
    vol_factor = min(volatility * 50, 1.0)
    w_mom = 0.5 + 0.3 * vol_factor
    w_mr = 0.5 - 0.3 * vol_factor

    signal = w_mom * momentum - w_mr * deviation

    # === 5) Allocation par fonction sigmoïde ===
    # évite les sauts brusques
    from math import tanh
    allocation_asset = 0.5 + 0.4 * tanh(signal * 5)

    # bornes de sécurité
    allocation_asset = max(0.1, min(0.9, allocation_asset))
    # === 6) Filtre de Tendance à Long Terme (MA 50) ===
    if len(history) < 50:
        # On maintient l'allocation calculée
        pass 
    else:
        ma50 = sum(history[-50:]) / 50
        tlt_deviation = (price - ma50) / ma50

        # Réduction: 1.0 si TLT est positif, 0.5 si TLT = -0.01 (-1%)
        # Tanh permet une modulation douce du facteur de réduction
        reduction_factor = (1 + tanh(tlt_deviation * 100)) / 2
        
        # On borne le facteur de réduction pour s'assurer qu'il soit entre 0.1 et 1.0
        reduction_factor = max(0.1, min(1.0, reduction_factor))
        
        # On multiplie l'allocation par ce facteur (réduit l'exposition en cas de forte tendance baissière)
        allocation_asset = allocation_asset * reduction_factor

    # =========================================================================
    # 🎯 FIN DE LA NOUVELLE SECTION 🎯
    # =========================================================================

    # === 7) Bornes finales de sécurité (Assuré que l'allocation finale reste valide) ===
    # Cette ligne est cruciale car elle garantit que même après la multiplication par le facteur de réduction,
    # le bot ne demandera pas d'allocation < 10% ou > 90%.
    allocation_asset = max(0.1, min(0.9, allocation_asset))

    return {
        "Asset A": allocation_asset,
        "Cash": 1 - allocation_asset
    }
